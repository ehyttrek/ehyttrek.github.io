/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_terms` VALUES
(1,"Uncategorized","uncategorized",0),
(2,"main-en","main-en",0);
