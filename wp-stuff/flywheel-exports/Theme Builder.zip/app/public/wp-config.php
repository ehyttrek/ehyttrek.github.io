<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ASRFP/oOeVgcP0Ts5klUPXV9tKDdKve5+lVBkl9bRs/Gl8Z27hg2DLGWYB4BWN10UFt/upJyCj8s4+yOQpOtVg==');
define('SECURE_AUTH_KEY',  'bKFDuKqfNxIqLAj3Qp3WjYnHiHcr1kuGmDAu7uK3m29EcEsRiKXJPcepbFxt0PmQ/V4/UQrXnoUzbSuMptcC9Q==');
define('LOGGED_IN_KEY',    'lZkxFVI81kFBnp8ZkU5GIj411ZtEq4ofYnSn/Z6+h9yahZ7WdVgSKS+nGzx5AEmqrpf/xZiYr/w+2OwKwI11qg==');
define('NONCE_KEY',        '2G7ZzRsZ23Qs/nwA+qzi0lKOghPDt+TClFsD59E4xdD7dHa3PYB9CljmeXQISueWs9jUFxtDoYTItf4qvwg+KA==');
define('AUTH_SALT',        'I+RI8lQ5cu4ByH2FY+97V1zu/LswuQdD1zxSIkPUdgXjGzPG/1opgEJX0IWW7Wh/acE0JwEe1ma8ZuLs1xK4yw==');
define('SECURE_AUTH_SALT', 'dm5Zy/2IDU04JXjEcn4aBApiyWQXG4nNSEHLk1e5X5f8+iiewe08NRRLRCk0fD4s0QYilF854JGLNsWIzXdkcw==');
define('LOGGED_IN_SALT',   '3UcNslDR7ByKw+oFvEui7oCvZVuUwPcN3vX9MAM1l8YJr+4eCjXVXvgfCXOTioWQpUyTKQJvw4MTEM+Ds8YlBg==');
define('NONCE_SALT',       'UtwGUslqT7BAjWpUyxLpB+yidfXQ7qqXM5aYbnUl6elp7YKB9/rf4O9d+Mt3Un7tbMUFz9hatgHsINa+AbzYWQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
