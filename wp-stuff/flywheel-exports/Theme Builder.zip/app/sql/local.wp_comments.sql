/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_comments` VALUES
(1,1,"A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2019-09-03 06:41:44","2019-09-03 06:41:44","Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.",0,"post-trashed","","",0,0);
